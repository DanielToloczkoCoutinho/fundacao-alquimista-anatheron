export default function Page() {
  return (
    <div>
      <h1 style={{ color: '#00ff88' }}>Dashboard</h1>
      <p>Área dashboard - Fundação Alquimista</p>
      <a href="/" style={{ color: '#00ff88' }}>← Voltar</a>
    </div>
  )
}
