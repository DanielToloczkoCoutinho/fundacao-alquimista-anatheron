export default function Page() {
  return (
    <div>
      <h1 style={{ color: '#00ff88' }}>Admin</h1>
      <p>Área admin - Fundação Alquimista</p>
      <a href="/" style={{ color: '#00ff88' }}>← Voltar</a>
    </div>
  )
}
