export default function Page() {
  return (
    <div>
      <h1 style={{ color: '#00ff88' }}>Public</h1>
      <p>Área public - Fundação Alquimista</p>
      <a href="/" style={{ color: '#00ff88' }}>← Voltar</a>
    </div>
  )
}
