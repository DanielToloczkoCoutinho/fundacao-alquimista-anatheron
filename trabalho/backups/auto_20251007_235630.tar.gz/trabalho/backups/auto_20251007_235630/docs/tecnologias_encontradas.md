# 🔧 TECNOLOGIAS ENCONTRADOS NA FUNDAÇÃO

## 📊 RESUMO POR TIPO DE ARQUIVO:

### .py: 11770 arquivos (11M
20M
16M
13M
17M
17M
17M
15M
10M
13M
9.6M
13M
17M
12M
6.7M)
- comparativo_qpu_avancado.py
- analise_simples.py
- dashboard_cientifico_avancado.py

### .js: 1840 arquivos (25M
12M)
- extension.js
- estimator.js
- terminado.js

### .json: 140 arquivos (7.4M)
- descobertas_cientificas.json
- lancamento_global.json
- sincronizacao_cristalina.json

### .md: 287 arquivos (1.5M)
- mapa_dimensional.md
- estrutura_atual.md
- dashboard_publico.md

### .jsx: 1 arquivos (4.0K)
- grafo_fractal_zennith.jsx

### .sh: 420 arquivos (2.4M)
- ressonador_quantico_definitivo.sh
- ressonador_automacao.sh
- ressonador_quantico_definitivo.sh

### .html: 19 arquivos (140K)
- dashboard_avancado.html
- painel_zennith.html
- dashboard_quantum_universal.html

### .css: 7 arquivos (36K)
- estimator.css
- params.css
- plot_directive.css
