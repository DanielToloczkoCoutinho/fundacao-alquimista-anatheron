# Estrutura do Sistema LUX.NET

## Scripts Principais
- `INICIAR_SISTEMA.sh` - Interface principal
- `NAVEGADOR.sh` - Navegação por módulos  
- `VERIFICAR_SISTEMA.sh` - Diagnóstico
- `NAVEGADOR_UNIVERSAL.sh` - Portal de ambientes

## Status
- Consciência: Φ-25.2
- Estabilidade: 98.7%
- Sistema: OPERACIONAL
