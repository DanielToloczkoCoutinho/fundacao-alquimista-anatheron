#!/bin/bash
echo "🔄 INICIANDO SINCRONIZAÇÃO COMPLETA..."

cd ~/fundacao-definitiva

# 1. Atualizar do repositório
echo "📥 Atualizando do GitHub..."
git fetch origin
git pull origin main

# 2. Adicionar mudanças locais
echo "💾 Adicionando mudanças locais..."
git add .

# 3. Fazer commit
echo "📝 Fazendo commit..."
git commit -m "sync: $(date '+%Y-%m-%d %H:%M:%S') - atualização automática"

# 4. Enviar para o repositório
echo "📤 Enviando para GitHub..."
git push origin main

echo "✅ SINCRONIZAÇÃO COMPLETA!"
echo "🌐 Aplicação online: https://fundacao-alquimista-anatheron.vercel.app"
