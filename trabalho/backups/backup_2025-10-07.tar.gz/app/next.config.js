/** @type {import('next').NextConfig} */
const nextConfig = {
  // Configuração básica
}

module.exports = nextConfig
