export default function SignIn() {
  return (
    <div>
      <h1 style={{ color: '#00ff88' }}>🔐 Login</h1>
      <p>Página de autenticação</p>
      <a href="/" style={{ color: '#00ff88' }}>← Voltar</a>
    </div>
  )
}
