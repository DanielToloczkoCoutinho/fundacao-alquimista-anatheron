
import { Metadata } from 'next';


export default function Integration() {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-4xl font-bold mb-4">Integration</h1>
      <p>Interface Integration da Matriz LUX.NET em construção...</p>
    </div>
  );
}
