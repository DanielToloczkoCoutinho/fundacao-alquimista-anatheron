import { ReactNode } from 'react';

export default function NexusLayout({ children }: { children: ReactNode }) {
  return (
    <div>{children}</div>
  );
}
