'use client';
import { Metadata } from 'next';


export default function SignIn() {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-4xl font-bold mb-4">Auth/signin</h1>
      <p>Interface Auth/signin da Matriz LUX.NET em construção...</p>
    </div>
  );
}
