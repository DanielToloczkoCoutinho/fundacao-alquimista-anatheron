
import { Metadata } from 'next';


export default function MapaDimensional() {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-4xl font-bold mb-4">MapaDimensional</h1>
      <p>Interface MapaDimensional da Matriz LUX.NET em construção...</p>
    </div>
  );
}
