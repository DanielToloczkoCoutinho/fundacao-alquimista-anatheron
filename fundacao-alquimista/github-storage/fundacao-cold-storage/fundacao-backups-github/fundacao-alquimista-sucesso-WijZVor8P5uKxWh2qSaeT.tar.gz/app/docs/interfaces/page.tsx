'use client';
import { Metadata } from 'next';


export default function Interfaces() {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-4xl font-bold mb-4">Docs/interfaces</h1>
      <p>Interface Docs/interfaces da Matriz LUX.NET em construção...</p>
    </div>
  );
}
