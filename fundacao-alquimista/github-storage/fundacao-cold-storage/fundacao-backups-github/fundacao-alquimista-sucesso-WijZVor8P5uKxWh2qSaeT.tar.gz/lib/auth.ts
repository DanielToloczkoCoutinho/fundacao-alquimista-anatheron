export const simpleAuth = { verify: (u,p) => u===zennith&&p===quantum966, getUser: () => ({id:1,name:Zennith}) }
